This workspace is for a NextJS web project.

- Don't run the dev server, that's handled by another process.
- Don't initialize the project, that's handled by another process.
